"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.messages = exports.chats = void 0;
exports.chats = [
    {
        participant: []
    }
];
exports.messages = [
    {
        from: "",
        to: "",
        chatID: "",
        text: "new message from 1"
    },
    {
        from: "",
        to: "",
        chatID: "",
        text: "new message from 3"
    },
    {
        from: "",
        to: "",
        chatID: "",
        text: "new message from 2"
    },
    {
        from: "",
        to: "",
        chatID: "",
        text: "new message from 8"
    }
];
