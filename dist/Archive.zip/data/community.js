"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.communities = void 0;
exports.communities = [
    {
        admin: "",
        name: "Web Dev Simplified",
        description: "Simplifying the web for you",
        members: []
    },
    {
        admin: "",
        name: "Django",
        description: "Simplifying the django framework for you",
        members: []
    },
    {
        admin: "",
        name: "Typescript v2",
        description: "The all new Typescript",
        members: []
    }
];
